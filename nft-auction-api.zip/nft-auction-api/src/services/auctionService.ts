// Auction Service - Business Logic Layer
// Based on Week 3 - Service Layer Architecture pattern
// NFT auction concept from Week 9 - Algorand NFT auction lab

import { Auction, CreateAuctionRequest, Bid } from '../types/auction';
import { v4 as uuidv4 } from 'uuid';

// In-memory store (acts like our blockchain state from Week 9)
const auctions: Map<string, Auction> = new Map();

// Create a new NFT auction
export function createAuction(data: CreateAuctionRequest): Auction {
  const newAuction: Auction = {
    id: uuidv4(),
    nft: {
      id: uuidv4(),
      name: data.nftName,
      owner: data.seller,
    },
    startingPrice: data.startingPrice,
    currentBid: data.startingPrice,
    currentBidder: null,
    seller: data.seller,
    status: 'open',
    createdAt: new Date().toISOString(),
    closedAt: null,
    winner: null,
  };

  auctions.set(newAuction.id, newAuction);
  return newAuction;
}

// Get a single auction by ID
export function getAuction(id: string): Auction | undefined {
  return auctions.get(id);
}

// Get all auctions
export function getAllAuctions(): Auction[] {
  return Array.from(auctions.values());
}

// Place a bid on an auction
export function placeBid(bid: Bid): Auction | null {
  const auction = auctions.get(bid.auctionId);

  if (!auction) return null;

  // Auction must be open
  if (auction.status !== 'open') return null;

  // Bid must be higher than current bid
  if (bid.amount <= auction.currentBid) return null;

  // Seller cannot bid on their own auction
  if (bid.bidder === auction.seller) return null;

  // Update auction with new bid
  auction.currentBid = bid.amount;
  auction.currentBidder = bid.bidder;
  auctions.set(bid.auctionId, auction);

  return auction;
}

// Close an auction and declare winner
export function closeAuction(id: string): Auction | null {
  const auction = auctions.get(id);

  if (!auction) return null;
  if (auction.status !== 'open') return null;

  auction.status = 'closed';
  auction.closedAt = new Date().toISOString();
  auction.winner = auction.currentBidder;

  // Transfer NFT ownership to winner if there was a bid
  if (auction.winner) {
    auction.nft.owner = auction.winner;
  }

  auctions.set(id, auction);
  return auction;
}
